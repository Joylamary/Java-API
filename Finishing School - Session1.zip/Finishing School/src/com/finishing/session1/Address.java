package com.finishing.session1;

public class Address {

	String addrID = null;
	String streetName = null;
	String city = null;
	
	public Address(String addrID, String streetName, String city) {
		this.addrID = addrID;
		this.streetName = streetName;
		this.city = city;
	}
	
	public String getAddrID() {
		return addrID;
	}
	public void setAddrID(String addrID) {
		this.addrID = addrID;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Address [addrID=" + addrID + ", streetName=" + streetName + ", city=" + city + "]";
	}
	
}
