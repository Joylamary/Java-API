package com.finishing.session1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Employee {

	int empID;
	String firstName = null;
	String lastName = null;
	int salary;
	Address addr;
	Department dept;

	public Employee(int empID, String firstName, String lastName, int salary, Address addr, Department dept) {
		this.empID = empID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.addr = addr;
		this.dept = dept;
	}

	public int getEmpID() {
		return empID;
	}

	public void setEmpID(int empID) {
		this.empID = empID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public Address getAddr() {
		return addr;
	}

	public void setAddr(Address addr) {
		this.addr = addr;
	}

	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	@Override
	public String toString() {
		return "Employee [empID=" + empID + ", firstName=" + firstName + ", lastName=" + lastName + ", salary=" + salary
				+ ", addr=" + addr + ", dept=" + dept + "]";
	}

	public static void main(String[] args) {
		Department d1 = new Department(101, "Maths", "Chennai");
		Department d2 = new Department(102, "Zoology", "Mumbai");
		Department d3 = new Department(103, "Chemistry", "Mumbai");
		Department d4 = new Department(104, "Botany", "Delhi");
		Department d5 = new Department(105, "IT", "Mumbai");
		
		Address addr1 = new Address("P101", "Westside", "Chennai");
		Address addr2 = new Address("T101", "Cross Street", "Madurai");
		Address addr3 = new Address("T102", "Middle Street", "Madurai");
		Address addr4 = new Address("P102", "Cross Town", "Chennai");
		
		ArrayList<Employee> arraylist = new ArrayList<Employee>();
		arraylist.add(new Employee(1, "Tom", "J", 50000, addr1, d1));
		arraylist.add(new Employee(2, "Jack", "P", 25000, addr2, d2));
		arraylist.add(new Employee(6, "Joe", "P", 25000, addr2, d2));
		arraylist.add(new Employee(3, "Peter", "Pat", 40000, addr4, d3));
		arraylist.add(new Employee(4, "Tom", "J", 50000, addr2, d4));
		arraylist.add(new Employee(5, "Peter", "Pat", 40000, addr3, d5));
		
		Comparator<Employee> sortempFirstName = new Comparator<Employee>() {			
			public int compare(Employee o1, Employee o2) {
				return o1.getFirstName().compareTo(o2.getFirstName());
			}
		};
		
		Comparator<Employee> sortempID = new Comparator<Employee>() {
			public int compare(Employee o1, Employee o2) {
				if(o1.getEmpID()>o2.getEmpID())
						return 1;
				else if(o1.getEmpID()<o2.getEmpID()){
					return -1;
				}
				else{
					return 0;
				}
			}
		};
		
		Comparator<Employee> sortEmpSalary = new Comparator<Employee>() {
			public int compare(Employee o1, Employee o2) {
				if(o1.getSalary()>o2.getSalary())
						return 1;
				else if(o1.getSalary()<o2.getSalary()){
					return -1;
				}
				else{
					return 0;
				}
			}
		};
		
		Comparator<Employee> sortDeptLoc = new Comparator<Employee>() {
			public int compare(Employee o1, Employee o2) {
				return o1.getDept().getLocation().compareTo(o2.getDept().getLocation());
			}
		};
		
		Comparator<Employee> sortAddrCity = new Comparator<Employee>() {
			public int compare(Employee o1, Employee o2) {
				return o1.getAddr().getCity().compareTo(o2.getAddr().getCity());
			}
		};

		Collections.sort(arraylist,sortempFirstName);
		
		System.out.println("Sort by employee's First Name");

		for (Employee str : arraylist) {
			System.out.println(str.toString());
		}
		
		Collections.sort(arraylist,sortempID);
		
		System.out.println("Sort by employee ID");

		for (Employee str : arraylist) {
			System.out.println(str.toString());
		}
		
		Collections.sort(arraylist,sortEmpSalary);
		
		System.out.println("Sort by Employee Salary");

		for (Employee str : arraylist) {
			System.out.println(str.toString());
		}
		
		Collections.sort(arraylist,sortDeptLoc);
		
		System.out.println("Sort by Department Location");

		for (Employee str : arraylist) {
			System.out.println(str.toString());
		}
		
		Collections.sort(arraylist,sortAddrCity);
		
		System.out.println("Sort by City");

		for (Employee str : arraylist) {
			System.out.println(str.toString());
		}
	}

}
