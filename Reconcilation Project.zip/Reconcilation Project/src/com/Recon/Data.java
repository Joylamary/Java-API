package com.Recon;

import java.time.LocalDate;

public class Data {
	
	private String transactionID;
	private String accountID;
	private LocalDate postingDate;
	private double amount;
	
	public String getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	public String getAccountID() {
		return accountID;
	}
	public void setAccountID(String accountID) {
		this.accountID = accountID;
	}
	public LocalDate getPostingDate() {
		return postingDate;
	}
	public void setPostingDate(LocalDate random) {
		this.postingDate = random;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Data [transactionID=" + transactionID + ", accountID=" + accountID + ", postingDate=" + postingDate
				+ ", amount=" + amount + "]";
	}

}
