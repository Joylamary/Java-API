package com.Recon;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ReportGeneration {

	public static ArrayList<ArrayList<Data>> readFiles(String file1, String file2) {
		ArrayList<ArrayList<Data>> dataOfTwoFiles = new ArrayList<ArrayList<Data>>();
		Path filePath1 = Paths.get(file1);
		Path filePath2 = Paths.get(file2);
		ArrayList<Data> reportFile1 = new ArrayList<Data>();
		ArrayList<Data> reportFile2 = new ArrayList<Data>();
		ArrayList<String> weakreport = new ArrayList<String>();
		List<String> fileAsList1 = null;
		List<String> fileAsList2 = null;
		// read file into stream, try-with-resources
		try (Stream<String> lines1 = Files.lines(filePath1)) {
			fileAsList1 = lines1.collect(Collectors.toList());// File1 to List
			for (String value : fileAsList1) {
				Data data = new Data();
				String[] values = value.split(";");
				data.setTransactionID(values[0].trim());
				data.setAccountID(values[1].trim());
				DateTimeFormatter df = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
				LocalDate random = LocalDate.parse(values[2].trim(), df);
				data.setPostingDate(random);
				data.setAmount(Double.parseDouble(values[3].trim()));
				reportFile1.add(data);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		// read file into stream, try-with-resources
		try (Stream<String> lines2 = Files.lines(filePath2)) {
			fileAsList2 = lines2.collect(Collectors.toList());// File1 to List
			for (String value : fileAsList2) {
				Data data = new Data();
				String[] values = value.split(";");
				data.setTransactionID(values[0].trim());
				data.setAccountID(values[1].trim());
				try {
					DateTimeFormatter df = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
					LocalDate random = LocalDate.parse(values[2].trim(), df);
					data.setPostingDate(random);
				} catch (DateTimeParseException e) {
					weakreport.add(data.getTransactionID());
				}
				data.setAmount(Double.parseDouble(values[3].trim()));
				reportFile2.add(data);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		dataOfTwoFiles.add(reportFile1);
		dataOfTwoFiles.add(reportFile2);
		/*
		 * boolean identicalID =
		 * DataFunctions.compareOrderLists(reportFile1,reportFile2);
		 * System.out.println(identicalID);
		 */
		return dataOfTwoFiles;
	}

	static void exactMatchReport(ArrayList<Data> listOne, ArrayList<Data> listTwo) {
		ArrayList<List<Data>> strongMatchreport = new ArrayList<List<Data>>();

		// compare two list of objects
		boolean filteredList = listOne.stream().equals(listTwo.stream());

		List<Data> filterListOne = listOne.stream()
				.filter(two -> listTwo.stream()
						.anyMatch(one -> one.getTransactionID().charAt(1) == two.getTransactionID().charAt(1)
								&& one.getAccountID().equals(two.getAccountID()) && one.getPostingDate() != null
								&& two.getPostingDate() != null && one.getPostingDate().isEqual(two.getPostingDate())
								&& (one.getAmount() == two.getAmount())))
				.collect(Collectors.toList());
		// System.out.println(filterListOne.toString());

		List<Data> filterListTwo = listTwo.stream()
				.filter(one -> listOne.stream()
						.anyMatch(two -> two.getTransactionID().charAt(1) == one.getTransactionID().charAt(1)
								&& two.getAccountID().equals(one.getAccountID()) && two.getPostingDate() != null
								&& one.getPostingDate() != null && two.getPostingDate().isEqual(one.getPostingDate())
								&& (two.getAmount() == one.getAmount())))
				.collect(Collectors.toList());

		strongMatchreport.add(filterListOne);
		strongMatchreport.add(filterListTwo);
		// System.out.println(strongMatchreport.toString());
	}

	static void weakMatchReport(ArrayList<Data> listOne, ArrayList<Data> listTwo) {
		ArrayList<List<Data>> weakMatchreport = new ArrayList<List<Data>>();

		List<Data> filterweakListOne = listOne.stream()
				.filter(two -> listTwo.stream()
						.anyMatch(one -> one.getTransactionID().charAt(1) == two.getTransactionID().charAt(1)
								&& one.getAccountID().equals(two.getAccountID())
								&& (two.getPostingDate() != null && one.getPostingDate() != null
								&& DataFunctions.dateDiff(one.getPostingDate(), two.getPostingDate()) ==1)
								&& (one.getAmount() != two.getAmount()
								&& DataFunctions.amtDiffinList(one.getAmount(), two.getAmount()) >= 0.01)))
				.collect(Collectors.toList());

		List<Data> filterweakListTwo = listTwo.stream()
				.filter(one -> listOne.stream()
						.anyMatch(two -> one.getTransactionID().charAt(1) == two.getTransactionID().charAt(1)
								&& one.getAccountID().equals(two.getAccountID())
								&& (two.getPostingDate() != null && one.getPostingDate() != null
								&& DataFunctions.dateDiff(one.getPostingDate(), two.getPostingDate())==1)
								&& (one.getAmount() != two.getAmount()
								&& DataFunctions.amtDiffinList(one.getAmount(), two.getAmount()) >= 0.01)))
				.collect(Collectors.toList());

		weakMatchreport.add(filterweakListOne);
		weakMatchreport.add(filterweakListTwo);
		//System.out.println(weakMatchreport.toString());
	}
	
	static void XBreaksYBreaks(ArrayList<Data> listOne, ArrayList<Data> listTwo) {
		ArrayList<List<Data>> XbreaksMatchreport = new ArrayList<List<Data>>();
		ArrayList<List<Data>> YbreaksMatchreport = new ArrayList<List<Data>>();


		/*List<Data> filterXBreakOne = listOne.stream()
				.foreach(two -> listTwo.stream()
				.anyMatch(one -> one.getTransactionID().charAt(1) == two.getTransactionID().charAt(1)
				&& !(one.getAccountID().equals(two.getAccountID())
				&& one.getPostingDate().equals(two.getPostingDate())
				&& one.getAmount() == two.getAmount())))
				.collect(Collectors.toList());
		// System.out.println(filterListOne.toString());

		List<Data> filterYBreakOne = listTwo.stream()
				.filter(one -> listOne.stream()
						.anyMatch(two -> one.getTransactionID().charAt(1) != two.getTransactionID().charAt(1)
						&& (!one.getAccountID().equals(two.getAccountID())
					    && !one.getPostingDate().equals(two.getPostingDate())
						&& one.getAmount() != two.getAmount())))
						.collect(Collectors.toList());

		XbreaksMatchreport.add(filterXBreakOne);
		YbreaksMatchreport.add(filterYBreakOne);
		//System.out.println(XbreaksMatchreport.toString());
		System.out.println(YbreaksMatchreport.toString());*/
	}
}
