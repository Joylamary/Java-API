package com.Recon;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.function.BinaryOperator;

public class DataFunctions {

	static double amtDiffinList(double amt1, double amt2){
	BinaryOperator<Double> amtDiff =(input1,input2) -> input1 - input2;
	return amtDiff.apply(amt1, amt2);
	}
	

	static int dateDiff(LocalDate date1, LocalDate date2){
		boolean result = date2.isAfter(date1);
		long noOfDaysBetween;
		if(result){
		noOfDaysBetween = ChronoUnit.DAYS.between(date1, date2);
		}else{
		noOfDaysBetween = ChronoUnit.DAYS.between(date2, date1);			
		}
		
		if(noOfDaysBetween>1 
				&& (date1.getDayOfWeek().equals("FRIDAY") && date2.getDayOfWeek().equals("MONDAY"))) {
			return 0;
		}else if(date1.equals(date2)) {
			return 1;
		}
		
		return 1;
	}

}