package com.Recon;

import java.util.ArrayList;

public class TestReport {

	public static void main(String[] args) {
		ArrayList<ArrayList<Data>> dataOfTwoFiles = null;
		dataOfTwoFiles = ReportGeneration.readFiles("G:/Joy Learnings/CG Learning Materials/X_set.txt", 
				"G:/Joy Learnings/CG Learning Materials/Y_set.txt");
		ReportGeneration.exactMatchReport(dataOfTwoFiles.get(0),dataOfTwoFiles.get(1));
		ReportGeneration.weakMatchReport(dataOfTwoFiles.get(0),dataOfTwoFiles.get(1));
		ReportGeneration.XBreaksYBreaks(dataOfTwoFiles.get(0),dataOfTwoFiles.get(1));
	}
}
