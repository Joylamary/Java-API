package com.finishing.session1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class CrudOperationsSorting {

	public static void addEmployee(ArrayList<Employee> arraylist, Address addr, Department d) {
		arraylist.add(new Employee(7, "Tom", "Jckie", 10000, addr, d));
		System.out.println("Add new Employee");

		for (Employee str : arraylist) {
			System.out.println(str.toString());
		}
	}

	public static void removeEmployee(ArrayList<Employee> arraylist) {
		System.out.println("Remove Employee in Last Position");
		arraylist.remove(arraylist.size()-1);

		for (Employee str : arraylist) {
			System.out.println(str.toString());
		}
	}

	public static void sortByEmployeeFirstName(ArrayList<Employee> arraylist) {
		Comparator<Employee> sortempFirstName = new Comparator<Employee>() {
			public int compare(Employee o1, Employee o2) {
				return o1.getFirstName().compareTo(o2.getFirstName());
			}
		};

		Collections.sort(arraylist, sortempFirstName);
		System.out.println("Sort by employee's First Name");

		for (Employee str : arraylist) {
			System.out.println(str.toString());
		}
	}

	public static void sortByEmployeeID(ArrayList<Employee> arraylist) {
		Comparator<Employee> sortempID = new Comparator<Employee>() {
			public int compare(Employee o1, Employee o2) {
				if (o1.getEmpID() > o2.getEmpID())
					return 1;
				else if (o1.getEmpID() < o2.getEmpID()) {
					return -1;
				} else {
					return 0;
				}
			}
		};
		
		Collections.sort(arraylist, sortempID);
		System.out.println("Sort by employee ID");

		for (Employee str : arraylist) {
			System.out.println(str.toString());
		}
	}

	public static void sortByEmployeeSalary(ArrayList<Employee> arraylist) {
		Comparator<Employee> sortEmpSalary = new Comparator<Employee>() {
			public int compare(Employee o1, Employee o2) {
				if (o1.getSalary() > o2.getSalary())
					return 1;
				else if (o1.getSalary() < o2.getSalary()) {
					return -1;
				} else {
					return 0;
				}
			}
		};

		Collections.sort(arraylist, sortEmpSalary);
		System.out.println("Sort by Employee Salary");

		for (Employee str : arraylist) {
			System.out.println(str.toString());
		}
	}

	public static void sortByCity(ArrayList<Employee> arraylist) {
		Comparator<Employee> sortAddrCity = new Comparator<Employee>() {
			public int compare(Employee o1, Employee o2) {
				return o1.getAddr().getCity().compareTo(o2.getAddr().getCity());
			}
		};

		Collections.sort(arraylist, sortAddrCity);
		System.out.println("Sort by City");

		for (Employee str : arraylist) {
			System.out.println(str.toString());
		}

	}

	public static void sortByDeptLoc(ArrayList<Employee> arraylist) {
		Comparator<Employee> sortDeptLoc = new Comparator<Employee>() {
			public int compare(Employee o1, Employee o2) {
				return o1.getDept().getLocation().compareTo(o2.getDept().getLocation());
			}
		};

		Collections.sort(arraylist, sortDeptLoc);
		System.out.println("Sort by Department Location");

		for (Employee str : arraylist) {
			System.out.println(str.toString());
		}
	}
	
	public static void sortByDeptLocDesc(ArrayList<Employee> arraylist) {
		Comparator<Employee> sortDeptLoc = new Comparator<Employee>() {
			public int compare(Employee o1, Employee o2) {
				return o2.getDept().getLocation().compareTo(o1.getDept().getLocation());
			}
		};

		Collections.sort(arraylist, sortDeptLoc);
		System.out.println("Sort by Department Location DESC");

		for (Employee str : arraylist) {
			System.out.println(str.toString());
		}
	}
	
	public static void main(String[] args) {
		Department d1 = new Department(101, "Maths", "Chennai");
		Department d2 = new Department(102, "Zoology", "Mumbai");
		Department d3 = new Department(103, "Chemistry", "Mumbai");
		Department d4 = new Department(104, "Botany", "Delhi");
		Department d5 = new Department(105, "IT", "Mumbai");

		Address addr1 = new Address("P101", "Westside", "Chennai");
		Address addr2 = new Address("T101", "Cross Street", "Madurai");
		Address addr3 = new Address("T102", "Middle Street", "Madurai");
		Address addr4 = new Address("P102", "Cross Town", "Chennai");

		ArrayList<Employee> arraylist = new ArrayList<Employee>();
		arraylist.add(new Employee(1, "Tom", "J", 50000, addr1, d1));
		arraylist.add(new Employee(2, "Jack", "P", 25000, addr2, d2));
		arraylist.add(new Employee(6, "Joe", "P", 25000, addr2, d2));
		arraylist.add(new Employee(3, "Peter", "Pat", 40000, addr4, d3));
		arraylist.add(new Employee(4, "Tom", "J", 50000, addr2, d4));
		arraylist.add(new Employee(5, "Peter", "Pat", 40000, addr3, d5));
		
		sortByEmployeeID(arraylist);
		sortByEmployeeFirstName(arraylist);
		sortByEmployeeSalary(arraylist);
		sortByCity(arraylist);
		sortByDeptLoc(arraylist);
		sortByDeptLocDesc(arraylist);
		addEmployee(arraylist, addr4, d3);
		removeEmployee(arraylist);
	}

}
