package com.finishing.session1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Employee {

	int empID;
	String firstName = null;
	String lastName = null;
	int salary;
	Address addr;
	Department dept;

	public Employee(int empID, String firstName, String lastName, int salary, Address addr, Department dept) {
		this.empID = empID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.addr = addr;
		this.dept = dept;
	}

	public int getEmpID() {
		return empID;
	}

	public void setEmpID(int empID) {
		this.empID = empID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public Address getAddr() {
		return addr;
	}

	public void setAddr(Address addr) {
		this.addr = addr;
	}

	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	@Override
	public String toString() {
		return "Employee [empID=" + empID + ", firstName=" + firstName + ", lastName=" + lastName + ", salary=" + salary
				+ ", addr=" + addr + ", dept=" + dept + "]";
	}
}
