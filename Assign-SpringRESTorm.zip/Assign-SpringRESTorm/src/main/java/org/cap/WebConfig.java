package org.cap;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@EnableWebMvc
@ComponentScan("org.cap")
@EnableTransactionManagement
public class WebConfig implements WebMvcConfigurer {

	@Bean
	public LocalEntityManagerFactoryBean getEntityManagerFactoryBean() {
		LocalEntityManagerFactoryBean factoryBeaan = new LocalEntityManagerFactoryBean();
		factoryBeaan.setPersistenceUnitName("Assigncapg");
		return factoryBeaan;
	}

	@Bean
	public JpaTransactionManager getTransactionManager() {
		JpaTransactionManager JPAtransManager = new JpaTransactionManager(getEntityManagerFactoryBean().getObject());
		return JPAtransManager;
	}

	//Let spring container know from where to pull the static resources
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("swagger-ui.html").addResourceLocations("classpath:/META-INF/resources/");
		registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");
	}
}
