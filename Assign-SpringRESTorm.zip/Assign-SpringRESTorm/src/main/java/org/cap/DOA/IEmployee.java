package org.cap.DOA;

import java.util.List;

import org.cap.model.Employee;

public interface IEmployee {

	public List<Employee> getAllEmployeeDetails();

	public Employee findEmployeeDetail(Integer productId);

	public List<Employee> postAllEmployeeDetails(Employee employee);

	public List<Employee> deleteEmployeedetail(Integer productId);
	
	
}
