package org.cap.DOA;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.cap.model.Employee;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("employeedao")
@Transactional
public class EmployeeDOAImpl implements IEmployee{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public List<Employee> getAllEmployeeDetails() {
		List<Employee> employeeDetails = entityManager.createQuery("from Employee").getResultList();
		return employeeDetails;
	}

	@Override
	public Employee findEmployeeDetail(Integer employeeId) {
		Employee empDetail = entityManager.find(Employee.class, employeeId);
		return empDetail;
	}

	@Override
	public List<Employee> deleteEmployeedetail(Integer employeeId) {
		Employee empDetail = entityManager.find(Employee.class, employeeId);
		entityManager.remove(empDetail);
		return getAllEmployeeDetails();
	}

	@Override
	public List<Employee> postAllEmployeeDetails(Employee employee) {
		List<Employee> employeeDetails = new ArrayList<Employee>();
		int updated = entityManager.createNativeQuery("INSERT INTO Employee (employeeID, firstName, lastName, salary) VALUES (?,?,?,?)")
	      .setParameter(1, employee.getEmployeeId())
	      .setParameter(2, employee.getFirstName())
	      .setParameter(3, employee.getLastName())
	      .executeUpdate();
		if(updated>0) {
			employeeDetails = entityManager.createQuery("from Employee").getResultList();
		}
		return employeeDetails;
	}
	
}