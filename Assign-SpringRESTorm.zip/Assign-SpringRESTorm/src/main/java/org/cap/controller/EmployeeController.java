package org.cap.controller;

import java.util.List;

import org.cap.DOA.IEmployee;
import org.cap.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/emp")
public class EmployeeController {

	@Autowired
	private IEmployee employeedao;
	
	@GetMapping(value = "/getallEmployee")
	public ResponseEntity<List<Employee>> getAllEmployeeDetails() {
		List<Employee> employeedetails = employeedao.getAllEmployeeDetails();
		if (employeedetails.isEmpty() || employeedetails == null)
			return new ResponseEntity("Sorry!! EmployeeDetails are not available", HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Employee>>(employeedetails, HttpStatus.OK);
	}

	@GetMapping(value = "/findEmployee/{employeeID}")
	public ResponseEntity<Employee> findEmployeeDetails(@PathVariable("employeeID") Integer employeeID) {
		Employee emp = employeedao.findEmployeeDetail(employeeID);
		if (emp == null)
			return new ResponseEntity("Sorry!! Employee ID not available", HttpStatus.NOT_FOUND);
		return new ResponseEntity<Employee>(emp, HttpStatus.OK);
	}

	
	@PostMapping(value = "/postAllEmployee")
	public ResponseEntity<List<Employee>> postAllEmployeeDetails(@RequestBody Employee employee) {
		List<Employee> employeedetails = employeedao.postAllEmployeeDetails(employee);
		if (employeedetails.isEmpty())
			return new ResponseEntity("Sorry Insertion failed!!", HttpStatus.BAD_REQUEST);
		return new ResponseEntity<List<Employee>>(employeedetails, HttpStatus.OK);
	}
	
	@DeleteMapping
	public ResponseEntity<List<Employee>> deleteEmployeeDetails(@PathVariable("employeeID") Integer employeeID) {
		List<Employee> empList = employeedao.deleteEmployeedetail(employeeID);
		if (empList.isEmpty() && empList == null)
			return new ResponseEntity("Sorry!! Employee ID not available", HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Employee>>(empList, HttpStatus.OK);
	}
}
