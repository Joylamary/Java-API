package org.cap.boot;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Parameter;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.cap.model.Employee;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("capg");
		EntityManager entityManager = factory.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();

		/*
		 * Employee employee = new Employee("tom", "Jack", 120000); Employee employee1 =
		 * new Employee("Jerry", "thomson", 45435); Employee employee2 = new
		 * Employee("Ram", "Singh", 4566767); Employee employee3 = new Employee("Annie",
		 * "George", 1200);
		 */

		System.out.println("Get EmployeeID & Salary for the given salary");

		String query = "SELECT employeeId, salary from Employee e where e.salary > :param_salary";
		Query query2 = entityManager.createQuery(query);
		query2.setParameter("param_salary", 5000.0);

		List<Object[]> employeeSalary = query2.getResultList();
		for (Object[] emp : employeeSalary) {
			System.out.println("EmployeeID : " + String.valueOf(emp[0]));
			System.out.println("Salary : " + String.valueOf(emp[1]));
		}

		System.out.println("Get EmployeeID & Name for the given salary");

		String empIdNameQuery = "SELECT employeeId, firstName from Employee e where e.salary > :param_salary";
		Query query3 = entityManager.createQuery(empIdNameQuery);
		query3.setParameter("param_salary", 5000.0);

		List<Object[]> employeeName = query2.getResultList();
		for (Object[] emp : employeeName) {
			System.out.println("EmployeeID : " + String.valueOf(emp[0]));
			System.out.println("Salary : " + String.valueOf(emp[1]));
		}

		System.out.println("Minimum Salary from employee Table");
		String minSal = "SELECT min(salary) from Employee e";
		Query minSalQuery = entityManager.createQuery(minSal);
		System.out.println("Min Salary" + minSalQuery.getSingleResult());

		System.out.println("Maximum Salary from employee Table");
		String maxSal = "SELECT max(salary) from Employee e";
		Query maxSalQuery = entityManager.createQuery(maxSal);
		System.out.println("Max Salary" + maxSalQuery.getSingleResult());

		System.out.println("Get all the employee whose salary > avg(salary)");
		String avgSal = "from Employee e where e.salary > (select avg(e.salary) from Employee e)";
		Query query5 = entityManager.createQuery(avgSal);

		List<Employee> avgSalemployees = query5.getResultList();
		for (Employee emp : avgSalemployees)
			System.out.println(emp);

		System.out.println("Get all the employee whose salary > avg(salary)");
		String countAvgSal = "SELECT count(e.employeeId) from Employee e where e.salary > (select avg(e.salary) from Employee e)";
		Query query6 = entityManager.createQuery(countAvgSal);
		Long countAvgSalemployees = (Long) query6.getSingleResult();
		System.out.println("Count of employee salary greater tahn Average" + countAvgSalemployees);
		

		System.out.println("Employee details using Like operator");
		String empIdLikeName = "from Employee e where e.firstName like 't%'";
		Query query4 = entityManager.createQuery(empIdLikeName);
		// query4.setParameter("param_name", "t%");
		List<Employee> employeesLike = query4.getResultList();
		for (Employee emp : employeesLike)
			System.out.println(emp);

		/*
		 * entityManager.persist(employee); entityManager.persist(employee1);
		 * entityManager.persist(employee2); entityManager.persist(employee3);
		 */
		transaction.commit();
		entityManager.close();
		factory.close();
	}

}
