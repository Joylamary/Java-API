package com.Recon;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ReportGeneration {

	public static ArrayList<Data> readFiles(String file) {
		Path filePath1 = Paths.get(file);
		ArrayList<Data> reportFile = new ArrayList<Data>();
		List<String> fileAsList = null;
		// read file into stream, try-with-resources
		try (Stream<String> lines1 = Files.lines(filePath1)) {
			fileAsList = lines1.collect(Collectors.toList());// File1 to List
			for (String value : fileAsList) {
				Data data = new Data();
				String[] values = value.split(";");
				data.setTransactionID(values[0].trim());
				data.setAccountID(values[1].trim());
				DateTimeFormatter df = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
				LocalDate random = LocalDate.parse(values[2].trim(), df);
				data.setPostingDate(random);
				data.setAmount(Double.parseDouble(values[3].trim()));
				reportFile.add(data);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return reportFile;
	}

	static void generateReport(ArrayList<Data> listOne, ArrayList<Data> listTwo) {
		ArrayList<String> exactMatch = new ArrayList<String>();
		ArrayList<String> weakMatch = new ArrayList<String>();
		ArrayList<String> xBreak = new ArrayList<String>();
		ArrayList<String> yBreak = new ArrayList<String>();

		for (int i = 0; i < listOne.size(); i++) {
			Data xSet = listOne.get(i);
			Data ySet = listTwo.get(i);
			if (xSet.equals(ySet)) {
				exactMatch.add(xSet.getTransactionID() + "" + ySet.getTransactionID() + " ");
			} else if (xSet.getAccountID().equals(ySet.getAccountID())
					&& (xSet.getAmount().equals(ySet.getAmount())
							|| DataFunctions.amtDiffinList(xSet.getAmount(), ySet.getAmount()))
					&& (xSet.getPostingDate().equals(ySet.getPostingDate())
							|| DataFunctions.dateDiff(xSet.getPostingDate(), ySet.getPostingDate()))) {
				weakMatch.add(xSet.getTransactionID() + "" + ySet.getTransactionID() + " ");
			} else {
				xBreak.add(xSet.getTransactionID() + " ");
				yBreak.add(ySet.getTransactionID() + " ");
			}
		}
		System.out.println("Exact Matches# "+exactMatch.toString());
		System.out.println("Weak Matches# "+weakMatch.toString());
		System.out.println("X Breaks# "+xBreak.toString());
		System.out.println("Y Breaks# "+yBreak.toString());
	}
}
