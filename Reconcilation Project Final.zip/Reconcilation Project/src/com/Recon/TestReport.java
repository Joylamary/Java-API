package com.Recon;

import java.util.ArrayList;

public class TestReport {

	public static void main(String[] args) {
		ArrayList<Data> XFile = ReportGeneration.readFiles("G:/Joy Learnings/CG Learning Materials/X_set.txt");
		ArrayList<Data> YFile = ReportGeneration.readFiles("G:/Joy Learnings/CG Learning Materials/Y_set.txt");
		ReportGeneration.generateReport(XFile,YFile);
	}
}
