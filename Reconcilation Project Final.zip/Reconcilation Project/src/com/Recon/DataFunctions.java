package com.Recon;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.function.BinaryOperator;

public class DataFunctions {

	static boolean amtDiffinList(Double amt1, Double amt2) {
		BinaryOperator<Double> amtDiff = (input1, input2) -> input1 - input2;
		if (amtDiff.apply(amt1, amt2) > 0.01) {
			return false;
		} else if(amt1.equals(amt2-0.01)) {
			return true;
		}
		return false;
	}

	static boolean dateDiff(LocalDate date1, LocalDate date2) {
		boolean result = date2.isAfter(date1);
		long noOfDaysBetween;
		if (result) {
			noOfDaysBetween = ChronoUnit.DAYS.between(date1, date2);
		} else {
			noOfDaysBetween = ChronoUnit.DAYS.between(date2, date1);
		}

		if (noOfDaysBetween > 1 && (date1.getDayOfWeek().equals(DayOfWeek.FRIDAY) && (date2.getDayOfWeek().equals(DayOfWeek.SATURDAY)
				|| date2.getDayOfWeek().equals(DayOfWeek.SUNDAY) || date2.getDayOfWeek().equals(DayOfWeek.MONDAY)))) {
			return true;
		}

		if (date1.equals(date2.plusDays(-1))) {
			return true;
		}
		return false;
	}

}