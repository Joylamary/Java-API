package org.cap.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.model.Manufacturer;
import org.cap.model.Product;
import org.springframework.stereotype.Repository;

@Repository("productDao")
public class ProductDaoImpl implements IProductDao {

	private static AtomicInteger productId = new AtomicInteger(1234);
	private static AtomicInteger manufacturerId = new AtomicInteger(1);
	private static List<Product> db = getDummyDB();

	private static List<Product> getDummyDB() {
		List<Product> products = new ArrayList<Product>();
		Manufacturer manufatcturer = new Manufacturer(manufacturerId.getAndIncrement(), "Tom", "Jerry",
				"tom@gmail.com");
		products.add(new Product(productId.getAndIncrement(), "Laptop", 34, 45000.0, manufatcturer));
		products.add(new Product(productId.getAndIncrement(), "Mobile", 12, 23000.0, manufatcturer));

		Manufacturer manufatcturer1 = new Manufacturer(manufacturerId.getAndIncrement(), "Jack", "Thomson",
				"jack@gmail.com");
		products.add(new Product(productId.getAndIncrement(), "HeadSet", 23, 300.0, manufatcturer1));
		products.add(new Product(productId.getAndIncrement(), "Printer", 11, 67000.0, manufatcturer1));

		return products;
	}

	@Override
	public List<Product> getAllProducts() {

		return db;
	}

	@Override
	public Product findProduct(Integer productId) {
		for (Product product : db) {
			if (product.getProductId() == productId)
				return product;
		}
		return null;
	}

	@Override
	public List<Product> deleteProduct(Integer productId) {
		boolean flag = false;
		Iterator<Product> iterator = db.iterator();
		while (iterator.hasNext()) {
			Product product = iterator.next();
			if (product.getProductId() == productId) {
				flag = true;
				iterator.remove();
				break;
			}
		}
		if (flag)
			return db;
		else
			return null;
	}

	@Override
	public List<Product> insertProduct(Product product) {
		db.add(product);
		return db;
	}

	@Override
	public List<Product> updateProduct(Integer productId) {

		boolean flag = false;
		Iterator<Product> iterator = db.iterator();
		while (iterator.hasNext()) {
			Product product = iterator.next();
			if (product.getProductId() == productId) {
				flag = true;
				product.setProductName("Computer");
				break;
			}
		}
		if (flag)
			return db;
		else
			return null;
	}

	@Override
	public List<Product> updatepatchProduct(Product product) {
		boolean flag = false;
		for (Product prod : db) {
			if (prod.getProductId() == product.getProductId()) {
				flag = true;
				int index=db.indexOf(prod);
				db.set(index, product);
			}
		}
		if(!flag) {
			db.add(product);
		}
		return db;
	}

}
