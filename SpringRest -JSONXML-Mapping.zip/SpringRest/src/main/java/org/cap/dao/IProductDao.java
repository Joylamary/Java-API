package org.cap.dao;

import java.util.List;

import org.cap.model.Product;

public interface IProductDao {
	
	public List<Product> getAllProducts();

	public Product findProduct(Integer productId);

	public List<Product> deleteProduct(Integer productId);
	
	//Putmapping
	public List<Product> updateProduct(Integer productId);
	
	//Postmaping
	public List<Product> insertProduct(Product product);
	
	//Patchmaping
	public List<Product> updatepatchProduct(Product product);

}
