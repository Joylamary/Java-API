package org.cap.conotroller;

import java.util.List;

import org.cap.dao.IProductDao;
import org.cap.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ProductController {

	
	@Autowired
	private IProductDao productDao;
	
	/*@GetMapping - get resource from server*/
	@GetMapping("/products")
	public ResponseEntity<List<Product>> getAllProducts(){
		List<Product> products=productDao.getAllProducts();
		
		if(products==null || products.isEmpty() ) {
			return new ResponseEntity("Sorry! No Items Available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	@GetMapping("/products/{productId}")
	public ResponseEntity<Product> findProducts(
			@PathVariable("productId") Integer productId ){
		Product product=productDao.findProduct(productId);
		
		if(product==null ) {
			return new ResponseEntity("Sorry!Product Id Not Found!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}
	
	/*@PostMapping - create resource into server*/
	@PostMapping("/product")
	public ResponseEntity<List<Product>> insertProduct(@RequestBody Product product){
		List<Product> products=productDao.insertProduct(product);
		
		if(products==null) {
			return new ResponseEntity("Sorry! Insertion Failed!", 
					HttpStatus.EXPECTATION_FAILED);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	/*@PatchMapping - create/update resource*/
	@PatchMapping("/product")
	
	
	/*@PutMapping - partial update*/
	@PutMapping("/product")
	public ResponseEntity<List<Product>> updateProduct(
			@PathVariable("productId") Integer productId){
		List<Product> products=productDao.updateProduct(productId);
		
		if(products==null) {
			return new ResponseEntity("Sorry! Product Id not exists! Updation Error!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	
	@DeleteMapping("/products/{productId}")
	public ResponseEntity<List<Product>> deleteProduct(
			@PathVariable("productId") Integer productId){
		List<Product> products=productDao.deleteProduct(productId);
		
		if(products==null) {
			return new ResponseEntity("Sorry! Product Id not exists! Deletion Error!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	@GetMapping(value="/productsXML", produces= MediaType.APPLICATION_XML_VALUE )
	public ResponseEntity<List<Product>> getAllProductsXML(){
		List<Product> products=productDao.getAllProducts();
		
		if(products==null || products.isEmpty() ) {
			return new ResponseEntity("Sorry! No Items Available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
}
